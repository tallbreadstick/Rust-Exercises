# INSTRUCTIONS

Open `task.rs` and implement the given functions. You can use `main.rs` to test your functions.

To run all test cases, use the `cargo test` command. You pass the activity when all test cases pass.

Deadline: Friday - June 6, 2025