pub mod task;
pub mod test;

use task::{
    final_digit_sum,
    two_sum_lite,
    odd_even_product_sum
};

fn main() {
    // you can use this main file for testing your code
}
